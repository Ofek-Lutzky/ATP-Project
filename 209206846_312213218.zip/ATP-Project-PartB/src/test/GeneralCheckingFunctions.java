package test;

public class GeneralCheckingFunctions {

    public static boolean check3DMaze(){
        // if you have chosen to not do the Maze3D assignment, please change this value to false.
        // Note, that if this will be false, you will automatically get minus 10 in the score
        //of the first part of the project.
        boolean weChoseToDoTheMaze3DAssignment = true;
        return weChoseToDoTheMaze3DAssignment;

    }

    public static String getGithubLink(){
    //change the <username> in the link to the username of the student who created the github project:
        String githubLink = "https://github.com/Ofek-Lutzky/ATP-Project";
        return githubLink;
    }

}
